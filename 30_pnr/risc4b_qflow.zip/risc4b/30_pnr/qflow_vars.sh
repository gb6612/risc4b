#!/usr/bin/tcsh -f
#-------------------------------------------
# qflow variables for project /work/projects/risc4b/30_pnr
#-------------------------------------------

set projectpath=/work/projects/risc4b/30_pnr
set techdir=/work/projects/risc4b/30_pnr/tech
set sourcedir=/work/projects/risc4b/30_pnr/source
set synthdir=/work/projects/risc4b/30_pnr/synthesis
set layoutdir=/work/projects/risc4b/30_pnr/layout
set techname=osu018
set scriptdir=/usr/lib/qflow/scripts
set bindir=/usr/lib/qflow/bin
set logdir=/work/projects/risc4b/30_pnr/log
#-------------------------------------------

