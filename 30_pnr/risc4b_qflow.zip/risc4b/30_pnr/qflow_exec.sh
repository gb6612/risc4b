#!/usr/bin/tcsh -f
#-------------------------------------------
# qflow exec script for project /work/projects/risc4b/30_pnr
#-------------------------------------------

# /usr/lib/qflow/scripts/synthesize.sh /work/projects/risc4b/30_pnr risc4b /work/projects/risc4b/30_pnr/source/risc4b.v || exit 1
# /usr/lib/qflow/scripts/placement.sh -d /work/projects/risc4b/30_pnr risc4b || exit 1
# /usr/lib/qflow/scripts/opensta.sh  /work/projects/risc4b/30_pnr risc4b || exit 1
# /usr/lib/qflow/scripts/vesta.sh -a /work/projects/risc4b/30_pnr risc4b || exit 1
# /usr/lib/qflow/scripts/router.sh /work/projects/risc4b/30_pnr risc4b || exit 1
# /usr/lib/qflow/scripts/opensta.sh  -d /work/projects/risc4b/30_pnr risc4b || exit 1
# /usr/lib/qflow/scripts/vesta.sh -a -d /work/projects/risc4b/30_pnr risc4b || exit 1
# /usr/lib/qflow/scripts/migrate.sh /work/projects/risc4b/30_pnr risc4b || exit 1
# /usr/lib/qflow/scripts/drc.sh /work/projects/risc4b/30_pnr risc4b || exit 1
# /usr/lib/qflow/scripts/lvs.sh /work/projects/risc4b/30_pnr risc4b || exit 1
/usr/lib/qflow/scripts/gdsii.sh /work/projects/risc4b/30_pnr risc4b || exit 1
# /usr/lib/qflow/scripts/cleanup.sh /work/projects/risc4b/30_pnr risc4b || exit 1
# /usr/lib/qflow/scripts/display.sh /work/projects/risc4b/30_pnr risc4b || exit 1
